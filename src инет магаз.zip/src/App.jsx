import mainStyles from './App.module.css';
import Card from './components/card/Card';
import Header from './components/header/Header';
import Basket from './components/basket/Basket';
import { useEffect, useState } from 'react';

function App() {

  const product = [
    {id:1, name: "шик!", prise: 300},
    {id:2, name: "блеск!", prise: 1100},
    {id:3, name: "збс!", prise: 19500 }
  ];
  const [money, setMoney] = useState(0);
  const summ = (a,b)=> {
    if(b==="+"){
      setMoney(money+a);
    }
    else{
      setMoney(money-a);
    }
  }

  const [openBasket, setOpenBasket] = useState(false);

  const [yesSearch, setyesSearch] = useState(false);

  const serch = (event) => {
    const result = product.filter(product => product.name === event.target.value);
    if(result.length>0){
      setyesSearch(true)
    }
    else {
      setyesSearch(false)
    }
  }

  return (
    <div className={mainStyles.wrapper}>
      <Header
        money={money}
        click={()=>setOpenBasket(!openBasket)}
      />
      {openBasket && <Basket money={money} />}
      <div><input type="text" placeholder='Поиск' onInput={serch} className={yesSearch ? mainStyles.likeYes : null}/></div>
      <div className={mainStyles.body}>
        {product.map(product => 
          <Card key={product.id}
           id={product.id}
           name={product.name}
           prise={product.prise}
           summ={summ}
          />
        )}
      </div>
    </div>
  );
}

export default App;