import React from 'react'
import './inputFile.css'

export default function InputDate() {
    //логика, функция
    return (
        <input type="file" />
    )
}
