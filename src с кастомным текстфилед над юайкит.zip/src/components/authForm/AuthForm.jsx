import styles from './authForm.module.css';


export default function InputDate(props) {

    const { elem, tasks, setTasks } = { ...props };

    return (
        <div className={styles.countFalse}>
           
        </div>
    )
}
