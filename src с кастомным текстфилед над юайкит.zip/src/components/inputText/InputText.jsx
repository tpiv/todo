import React from 'react'
import './inputText.css'

export default function InputDate() {
    //логика, функция
    return (
        <input type="text" />
    )
}
