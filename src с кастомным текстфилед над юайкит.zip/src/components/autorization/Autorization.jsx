
import TextFieldCustom from '../textFieldCustom/TextFieldCustom';
import { Button } from '@consta/uikit/Button';
import { IconUser } from '@consta/icons/IconUser';
import { IconLock } from '@consta/icons/IconLock'; 
import { TextField } from "@consta/uikit/TextField";

import styles from './autorization.module.css';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';


export default function Autorization() {
    const {
        handleSubmit, 
        control,
        register,
        formState: {errors},

    } = useForm ({mode: "onBlur"});
    
    const onSubmit = (data) => {
        console.log(JSON.stringify(data));
    }
    useEffect(() => {
      
    
      return () => {
        
      }
    }, [])
    
    const [value, setValue] = useState(null);
    const handleChange = (val ) => setValue(val.value);
    return (
        <form className={styles.wrapper} onSubmit={handleSubmit(onSubmit)}>
                <div className={styles.wrapperForm}>
                <div className={styles.elemForm}>
                    <span className={styles.heading}>Вход в личный кабинет</span>
                </div>
      <div>
          {errors?.name && <span className={styles.errors}>{errors?.name?.message || "Ошибка"}</span>}
        </div>
                
                <div className={styles.elemForm}>
                    <TextFieldCustom
                        name="inn"
                        type="text"
                        placeholder="ИНН"
                        label="Введите ИНН"
                        leftSide={IconUser}
                        control={control}
                        rules={{
                            pattern: {
                                value: /^([0-9]{10})?$/,
                                message: "ИНН юр лиц состоит из 10 цифр"
                            },
                            required: "Поле обязательно для заполнения"
                        }}
                    />
                </div>

                <div className={styles.elemForm}>
                    <TextFieldCustom
                        name="pass"
                        type="password"
                        placeholder="Пароль"
                        label="Введите пароль"
                        leftSide={IconLock}
                        control={control}
                        rules={{
                            minLength: {
                                value: 5,
                                message: "Пароль должен иметь длинну от 5 до 20 символов"
                            },
                            maxLength: {
                                value: 20,
                                message: "Пароль должен иметь длинну от 5 до 20 символов"
                            },
                            required: "Поле обязательно для заполнения"
                        }}
                    />
                </div>
                
                <div className={styles.elemForm}>
                    <Button label="Войти" form="round" />
                </div>

                <div className={styles.elemForm}>
                    <div className={styles.lowerWrapper}>
                        <span>Забыли пароль?</span>
                        <span><a href="">Восстановить</a></span>
                    </div>
                    <span><a href="">Техническая поддержка</a></span>
                </div>
                </div>
        </form>
    )
}
