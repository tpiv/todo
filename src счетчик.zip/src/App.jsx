import './App.css';
import React from 'react';
import Сounter from './components/counter/Сounter';


function App() {
  
  return (
    <div className="App-new">
      <div className="container">
        <Сounter
        />
      </div>
    </div>
  );
}

export default App;
