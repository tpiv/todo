import './App.css';
import Todo from './components/todo/Todo';


function App() {

  return (
    <div className="App-new">
      <div className="container">
        <Todo />
      </div>
    </div>
  );
}

export default App;
