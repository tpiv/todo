import './App.css';
import React from 'react';
import Button from './components/button/Button';
import InputDate from './components/inputDate/InputDate';
import InputNumber from './components/inputNumber/InputNumber';
import InputText from './components/inputText/InputText';
import InputFile from './components/inputFile/InputFile';

function App() {
  const textButton = "Послать на";
  let valueData = React.createRef();
  const[value, getValue] = React.useState(22);
  
  return (
    <div className="App-new">
      <div className="container">
      <form className='form'>
            <div className="wrap">
            <InputDate
              valueData={valueData}
            />
          </div>
          <div className="wrap">
            <InputNumber 
              value={value}
              getValue={getValue}
            />
          </div>
          <div className="wrap">
            <InputText />
          </div>
          <div className="wrap">
            <InputFile />
          </div>
          <div className="wrap">
            <Button
              text={textButton}
            />
          </div>
        </form>
      </div>
    </div>
  );
}

export default App;
